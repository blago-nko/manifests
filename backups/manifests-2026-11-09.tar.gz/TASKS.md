# 📋 TASKS.md — Реестр задач и артефактов экосистемы `blago-nko`

> Краткосрочные задачи — ниже. Протокол ведения задач: [AGENTS.md](AGENTS.md) §5. Живые метрики: [docs/STATUS.md](docs/STATUS.md). Долгосрочные направления (P2) — в [ROADMAP.md](ROADMAP.md). **Тип документа:** живой реестр. Единый источник правды по **активным работам** и **состоянию артефактов** (скрипты / конфиги / workflows / компоненты).
> **Триггер обновления:** каждый закрытый протокол (смерженный PR) → немедленное обновление.
> **Исполнитель:** 🤖 ИИ-агент (бесплатные инструменты, доступные в РФ без VPN) → 👤 подтверждение Основателя.
> **Сроки:** не фиксируются (решение Основателя). Управление через **Фазы** и **Приоритеты**.
> **Иерархия:** документ подчинён САМ. Префиксы протоколов — по САМ п. 1.5 (`SAM-`, `CAN-`, `GP-`, `SUMKA-`, `MIG-`, `LIC-`, `INFRA-`).

---

## Текущее состояние (As-Is, снимок после «Эпохального сброса» 11.09.2026)

| Параметр | Состояние |
| :--- | :--- |
| НКО | ✅ Официально зарегистрирована |
| 13 сайтов на Hugo | 🟢 Функционируют на Blogger |
| Пантеон | 🟢 Функционирует на Blogger, ~350 страниц (цель 16 505) |
| САН | 🟢 Функционирует на Blogger |
| gallery | 🟡 Создан, виден в сети, без контента и оформления |
| Контент | ✅ Жив на Blogger — подлежит перепарсиванию |
| `shared-assets` | ❌ Удалён при сбросе 11.09.2026, пересоздаётся (задача INFRA-010) |
| `can-secure-dev` | 🟡 Org существует, пуста |
| Домены / DNS | ✅ Зарегистрированы, ведут на старые сайты (Blogger) |
| Secrets | ⚠️ Не проверены после сброса |

**Модель развития:** постоянно развивающаяся экосистема. НКО зарегистрирована, сайты функционируют на Blogger, выполняется поэтапная реализация манифестов.

## Легенда

**Статусы:** ⬜ Не начата · 🔄 В работе · ✅ Завершена · ⛔ Заблокирована
**Приоритеты:** 🔴 Критический · 🟠 Высокий · 🟡 Средний · 🟢 Низкий
**Фазы:** `0 Фундамент` → `1 Каркас` → `2 Наполнение/Миграция`
**Имя определено:** ✅ Да (можно сразу создавать/проверять) · ❌ Нет (концепт, требуется проектирование)

---

## ФАЗА 0 — ФУНДАМЕНТ

| ID | Задача | Подзадачи | Приор. | Ответств. | Статус | Комментарий |
| :--- | :--- | :--- | :---: | :--- | :---: | :--- |
| **LIC-001** | Решение по лицензионной модели | Зафиксировать ОДНУ модель: (а) **AGPLv3 + CC BY-NC 4.0** [рекомендуется] или (б) MIT + CC BY 4.0. Решение принимает Основатель | 🔴 | 👤 | ✅ | Закрыт PR 211: AGPLv3 (код) + CC BY-NC 4.0 (контент); детали в ЛИЦ.md |
| **LIC-002** | Синхронизация лицензий по всем файлам | Привести к единой модели: `README.md`, метаданные+тело `ЛИЦ.md`, `AGENTS.md`, `LICENSE`, `LICENSE-CONTENT` | 🔴 | 🤖→👤 | ✅ | Файлы приведены к модели; синхронизация и проверка в CI |
| **LIC-003** | Автопроверка лицензий | Контроль футера всех сайтов в `readme-license-check.yml` / `architecture-check.yml` | 🟠 | 🤖→👤 | ✅ | readme-license-check.yml активен на каждом PR |
| **PROC-002** | Роль «Хранитель графа» | Описать роль ИИ-агента в `AGENTS.md` (Протокол 016.5) | 🟠 | 🤖→👤 | ✅ | Роль описана в AGENTS.md (Протокол 016.5) |
| **INFRA-005** | Актуализация данных после сброса | Отразить реальное состояние репо/сайтов в `docs/manifests.yaml` | 🔴 | 🤖→👤 | ✅ | Данные синхронизированы sync-manifests; подтверждено VERIFY-002/003 |
| **SEC-001** | Аудит Secrets после сброса | Проверить уцелевшие секреты, скомпрометированные — ротировать | 🔴 | 👤 | ⬜ | Требует доступа Основателя |
| **ORG-001** | Верификация `can-secure-dev` | Проверить, что org пуста; подготовить к Этапу 2 САН | 🟡 | 👤 | ⬜ | ПДн-контур, 152-ФЗ |
| **PROC-001** | Автовалидация `TASKS.md` | В `manifest-consistency-check.yml`: у активных задач есть статус, у закрытых — результат | 🟠 | 🤖→👤 | ✅ | check_tasks_registry.py + шаг в manifest-consistency-check.yml |
| **VERIFY-001** | Верификация существующих скриптов | Проверить 10 `.py` файлов из `/scripts/` | 🔴 | 🤖→👤 | ✅ | Статус в Реестре |
| **VERIFY-002** | Верификация существующих workflows | Проверить 13 `.yml` из `.github/workflows/` | 🔴 | 🤖→👤 | ✅ | Статус в Реестре |
| **VERIFY-003** | Верификация конфигов и шаблонов | Проверить применимость 3 `.json`, шаблона PR, конфигов линтера, `manifests.yaml`, `STATUS.md` | 🟠 | 🤖→👤 | ✅ | Статус в Реестре |

---

## ФАЗА 1 — КАРКАС

| ID | Задача | Подзадачи | Приор. | Ответств. | Статус | Комментарий |
| :--- | :--- | :--- | :---: | :--- | :---: | :--- |
| **ORG-003** | Токен для автоматизации | Получить PAT с правами создания репо + настройки Branch Protection | 🟠 | 👤 | ⬜ | Зависимость для ORG-002, INFRA-010 |
| **ORG-002** | Применение Branch Protection | Применить `branch-protection.json`, `ruleset.json` через API | 🟠 | 👤/🤖 | ⬜ | Зависит от ORG-003 |
| **INFRA-010** | Пересоздание `shared-assets` | Репозиторий общих фронтенд-артефактов | 🟠 | 🤖→👤 | ✅ | Репозиторий создан (INFRA-033); подключение через submodule |
| **INFRA-011** | Публикация в GitHub Packages | `npm.pkg.github.com`, SemVer, только через CI | 🟡 | 🤖→👤 | ⬜ | Протокол 014 САМ |
| **INFRA-012** | Reusable workflows | `architecture-check`, `protocol-check`, `sync-manifests`, `publish-assets`, `ai-rules-sync` | 🟠 | 🤖→👤 | ⬜ | Унифицировать `protocol-check`↔`pr-prefix-check` |
| **INFRA-013** | Blago Ecosystem Bot | GitHub App для кросс-орг проверок | 🟡 | 🤖→👤 | ⬜ | САМ 3.3.3 |
| **INFRA-003** | Актуализация фактов в манифестах | Пантеон: 350 стр (не 16 505); статусы сайтов | 🔴 | 🤖→👤 | ⬜ | Манифесты должны отражать реальность |
| **DOC-001** | Указатели на `TASKS.md` в манифестах | В блоках со списками артефактов вставить ссылку на «Реестр артефактов» | 🔴 | 🤖→👤 | ⬜ | Новый подход к состоянию артефактов |
| **INFRA-004** | Наполнение «Реестра артефактов» | Ревизия и заполнение таблицы ниже | 🔴 | 🤖→👤 | ⬜ | Источник правды по артефактам |
| **INFRA-015** | Аудит и очистка устаревших удалённых веток | 21 ветка удалена; оставлены main + активные авто-ветки | 🟠 | 🤖→ | ✅ | Закрыт PR (этот) |
| **INFRA-016** | Фикс MD032 в AGENTS.md (пустые строки вокруг списков) | sed-вставка пустых строк | 🟢 | 🤖→ | ✅ | Закрыт PR 192 |
| **INFRA-017** | continue-on-error для Enable Auto-Merge в sync-manifests.yml | awk-вставка флага | 🟢 | →👤 | ✅ | Закрыт PR 193 |
| **INFRA-001** | Создание domains-graph.yaml | 14 доменов, роли, контуры, связи; таксономия — INFRA-020 | 🔴 | →👤 | 🔄 | Этот PR |
| **INFRA-018** | continue-on-error для Enable Auto-Merge во всех sync-workflows | awk-вставка флага | 🟠 | 🤖→👤 | ✅ | Закрыт PR 195 |
| **INFRA-019** | Удаление update-manifest-dates.yml (осцилляция дат) | git rm воркфлоу | 🔴 | 🤖→ | ✅ | Закрыт PR 199 |
| **INFRA-020** | Наполнение таксономии domains-graph, уточнение ролей хаба и r2 | общие категории и подтаксономии по 016.2 | 🟠 | 🤖→ | ⬜ | После INFRA-001 |
| **INFRA-021** | Снятие markdownlint-долга (ГРЕК-ПАНТЕОН.md; CHANGELOG.md отсутствует) | Убраны из ignores; .markdownlintignore удалён | 🟡 | → | ✅ | Закрыт PR 220 |
| **INFRA-022** | Восстановление обязательных секций STATUS.md + генерация из источников | 4 секции из domains-graph.yaml и manifests.yaml | 🔴 | 🤖→👤 | ✅ | Этот PR |
| **INFRA-026** | Патч update_status.py: генерация 4 обязательных секций STATUS.md | из domains-graph.yaml, manifests.yaml, TASKS.md | 🔴 | 🤖→👤 | ✅ | Этот PR |
| **INFRA-024** | Удалить auto-update-status.yml (битый дубль с путём STATUS.md) | git rm | 🟠 | → | ✅ | Этот PR |
| **INFRA-028** | pull-requests: write в update-status.yml | permissions для create-pull-request | 🔴 | → | ✅ | Закрыт PR 211 |
| **INFRA-029** | Контракт единственного писателя STATUS.md | sync_manifests не пишет STATUS; update_status.py из yaml; workflow регенерирует+валидирует | 🔴 | → | ✅ | Этот PR |
| **INFRA-030** | Убрать reviewers из авто-PR; timestamp-шаг удалён (stamp владеет генератор) | фикс "Unexpected end of JSON input" и шумовых авто-PR | 🔴 | → | ✅ | Этот PR |
| **INFRA-031** | Uptime-мониторинг доменов + алерты | UptimeRobot + Telegram + runbook | 🟡 | → | ⏸️ | Отложено до миграции 13 сайтов с Blogger |
| **INFRA-032** | Бэкапы ключевых файлов + runbook восстановления | weekly-backup в ветку backups; R2 и зеркало — этап 2 | 🟡 | → | 🔄 | Этап 1: workflow + runbook |
| **INFRA-033** | Создание blago-nko/shared-assets | Hugo-тема + Astro-компоненты + CookieConsent + RSS | 🟡 | 🤖→ | ✅ | Репозиторий blago-nko/shared-assets создан |
| **INFRA-034** | CONTRIBUTING/CODE_OF_CONDUCT/SECURITY/CHANGELOG | Инфраструктура контрибьюторов + issue templates + CODEOWNERS | 🟡 | → | ✅ | Этот PR |
| **INFRA-046** | Единый .markdownlint.yaml в shared-assets | Консистентность стиля с manifests; hotfix MD013 | 🟡 | → | ✅ | Hotfix после PR 1 shared-assets |
| **INFRA-047** | Стратегия миграции 14 сайтов с Blogger на Hugo/Astro | docs/migration/STRATEGY.md; MIG-001..014; hardening E2E | 🟡 | → | ✅ | Этот PR |
| **INFRA-048** | Hardening E2E (канонический www, ретраи, 429-skip) + дизайн-решения миграции | Объединён с INFRA-047; ПДн-формы, артефакты СУМКа, apex www | 🟡 | → | ✅ | В составе INFRA-047 |
| **INFRA-049** | Проверить apex TLS/редирект blagorussia.ru | E2E попал на apex с просроченным cert; канонический www валиден; настроить apex-редирект | 🟡 | | 🔄 | Не отказ: www работает |
| **INFRA-050** | Реестр артефактов СУМКа → shared-assets | docs/migration/SUMKA-MAPPING.md; mobile-first, JSON-LD, image sanitization и др. | 🟡 | → | ✅ | Этот PR |
| **INFRA-035** | Изоляция контура B (152-ФЗ) | Отдельные secrets + перенос can.blagorussia.ru на отдельный аккаунт | 🟡 | → | ⬜ | Этап 7 миграции, после финальной проверки 14 сайтов |
| **INFRA-036** | Тесты pytest + Playwright E2E + snapshot-тесты | Unit-тесты скриптов, E2E для 14 доменов, snapshot STATUS.md | 🟡 | → | ✅ | Этот PR |
| **INFRA-037** | Правило MSYS/Python в AGENTS.md (секция 1.5) + hotfix markdown-lint | Зафиксировать эмпирическое правило + починить MD028/MD060/MD012/MD031 | 🟡 | → | ✅ | Закрыт PR 228+230 |
| **INFRA-039** | Удалить FETCH_HEAD из main + защита .gitignore | Артефакт git pull попал в репозиторий из-за сбоя force push | 🔴 | → | ✅ | Закрыт PR 232 |
| **INFRA-040** | Реструктуризация README (навигация + цифры экосистемы) | Точка входа для людей; сжатие секции автосинхронизации | 🟡 | → | ✅ | Этот PR |
| **INFRA-041** | Кросс-ссылки документов верхнего уровня + check_docs_links.py | Матрица ссылок README/AGENTS/TASKS/ROADMAP/STATUS; ссылки STATUS только через генератор | 🟡 | → | ✅ | Этот PR |
| **INFRA-042** | Правило пересоздания конфликтных авто-PR в AGENTS.md | Попытка вставки 5.5.1 — конфликт с существующей нумерацией | 🔴 | → | ❌ | Отменён |
| **INFRA-043** | Правило пересоздания конфликтных авто-PR (AGENTS.md §5.5.3) + MD060 hotfix | Правильная нумерация 5.5.3 + авто-фикс MD060 в строке 6 | 🟡 | → | ✅ | Этот PR |
| **INFRA-044** | Сверка Фазы 0 + PROC-001 (автовалидация TASKS.md) | Дедупликация LIC-001, статусы LIC-002/003/PROC-002/INFRA-005 → ✅, check_tasks_registry.py | 🟡 | → | ✅ | Закрыт PR 252 |
| **INFRA-045** | Удаление легаси корневого STATUS.md | Дубликат docs/STATUS.md; workflow работает только с docs/ | 🟡 | → | ✅ | Закрыт PR 254 |
| **INFRA-107** | Разработка `image_sanitizer.py` (Pipeline 5 этапов) | EXIF strip → WebP → Resize ≤1600px → pHash → Watermark | 🔴 BLOCKER | 🤖→ | ⬜ | Критично для Blogger безлимита |
| **INFRA-108** | Настройка Blogger Gallery (`gallery.obrazslov.ru`) | Создание блога, привязка CNAME, получение API Key | 🔴 BLOCKER | 👤 | ⬜ | Источник правды для изображений |
| **INFRA-109** | Скрипт `upload_to_blogger.py` + интеграция с API | Автоматизация загрузки sanitized-файлов | 🔴 BLOCKER | 🤖→ | ⬜ | Зависит от INFRA-107, 108 |
| **INFRA-110** | Конфиг `image_storage_routing.json` в shared-assets | Маршрутизация типов файлов (Blogger/R2/Git) | 🟡 HIGH | → | ⬜ | Единый источник правил хранения |
| **INFRA-111** | Обновление шорткода `img.html` (srcset, lazy load) | Поддержка 4 размеров, fetchpriority для Hero | 🔴 BLOCKER | 🤖→👤 | ⬜ | Core Web Vitals LCP |
| **INFRA-112** | Внедрение `design-tokens.css` и базовой типографики | CSS-переменные цветов и шрифтов PT Sans/Serif | 🟡 HIGH | →👤 | ⬜ | Единый стандарт фронтенда |
| **INFRA-113** | Реализация `CookieConsent.js` и `footer-legal.html` | Юридическое требование 152-ФЗ и ЛИЦ | 🔴 BLOCKER | 🤖→ | ⬜ | Обязательный компонент футера |
| **INFRA-114** | Внедрение `StickyBottomBar.js` в тему Hugo | Mobile-First навигация (xs:320px) | 🟡 HIGH | →👤 | ⬜ | UX-требование Манифеста |
| **INFRA-115** | Настройка Pagefind (конфиг + JS) в теме Hugo | Исправление glob для подкаталогов GH Pages | 🟡 HIGH | → | ⬜ | Внутренний поиск по сайту |
| **INFRA-116** | Разработка `generate_redirect_map.py` | Парсинг sitemap Blogger → маппинг новых slug | 🔴 BLOCKER | 🤖→ | ⬜ | SEO-преемственность |
| **INFRA-117** | Разработка `validate_redirect_map.py` | Проверка циклов, дублей, валидности URL | 🟡 HIGH | 🤖→ | ⬜ | Качество данных редиректов |
| **INFRA-118** | Настройка `robots.txt` и `ai-hints.txt` | GEO-оптимизация, разрешение для GPTBot/Yandex | 🟡 MED | 🤖→ | ⬜ | Доступность для ИИ-поисковиков |

### Фаза 3: Миграция 14 сайтов с Blogger

| **ID** | Задача | Описание | Приоритет | Владелец | Статус | Комментарий |
| **MIG-001** | Миграция <www.blagorussia.ru> (хаб) | Hugo, сложная навигация, 13 рубрик; apex → www редирект | 🟡 | → | ⬜ | Этап 3 |
| **MIG-002** | Миграция obrazslov.ru (база знаний) | Hugo, пилот на staging. Текст мигрирован, SEO/поиск/тема проверены. Перевод на боевой домен — после блока артефактов. | 🟢 | → | 🔄 | Этап 1 частично: локализация обложек/URL-маппинг в блоке артефактов. |
| **MIG-003** | Миграция partnerstvo.blagorussia.ru (юридический хаб НП) | Hugo + секция «Документы»; ПДн-формы → Yandex Forms | 🟡 | → | ⬜ | Этап 3 |
| **MIG-004** | Миграция novosti.blagorussia.ru | Hugo, новостной поток | 🟡 | → | ⬜ | Этап 3 |
| **MIG-005** | Миграция ot-gorozan.blagorussia.ru | Hugo, медиа-контент; формы без ПДн | 🟡 | → | ⬜ | Этап 3 |
| **MIG-006** | Миграция obavlenia.blagorussia.ru | Hugo, объявления | 🟡 | → | ⬜ | Этап 3 |
| **MIG-007** | Миграция interesnye-mesta.obrazslov.ru | Hugo, архив | 🟡 | → | ⬜ | Этап 3 |
| **MIG-008** | Миграция moisites.blagorussia.ru | Hugo, школа | 🟡 | → | ⬜ | Этап 3 |
| **MIG-009** | Миграция joga.blagorussia.ru | Hugo, йога | 🟡 | → | ⬜ | Этап 3 |
| **MIG-010** | Миграция ideologia.obrazslov.ru | Hugo, тексты | 🟡 | → | ⬜ | Этап 3 |
| **MIG-011** | Миграция nasa-istoria.blagorussia.ru (Наша история) | Hugo; ПДн-формы → Yandex Forms | 🟡 | → | ⬜ | Этап 3 |
| **MIG-012** | Миграция grekpanteon.obrazslov.ru | Astro, пантеон (САМ §1.3) | 🟡 | → | ⬜ | Этап 3 |
| **MIG-013** | Миграция gallery.obrazslov.ru | Blogger, фотоархив (платформа не меняется); репозиторий gallery-npo под пайплайны | 🟡 | → | ⬜ | Этап 4 |
| **MIG-014** | Миграция can.blagorussia.ru (САН) | Next.js/Vercel; вместе со всеми сайтами; изоляция — после Этапа 6 | 🟡 | → | ⬜ | Этап 3 |

---

## ФАЗА 2 — НАПОЛНЕНИЕ / МИГРАЦИЯ

| ID | Задача | Подзадачи | Приор. | Ответств. | Статус | Комментарий |
| :--- | :--- | :--- | :---: | :--- | :---: | :--- |
| **MIG-015** | Спасение контента 11 RSS | Перепарсинг живых Blogger-сайтов, бэкап в R2/YOS (0 ₽) | 🟠 | 🤖→👤 | ⬜ | Пока контент жив |
| **MIG-016** | Спасение контента Пантеона | Перепарсинг ~350 страниц + синхронизация с Google Таблицей | 🟠 | 🤖→👤 | ⬜ | Источник — живая Таблица |
| **MIG-017** | Image Sanitization Pipeline | 5 этапов: скачивание оригинала (снятие размерного суффикса Blogger URL), EXIF-очистка, WebP, 4 размера 400–1600px, ресайз ≤1600px для безлимита Blogger | 🟠 | 🤖→👤 | ⬜ | Централизованный компонент |
| **MIG-018** | Оформление gallery | Контент, `ImageGallery`, `FAQPage`, блок «Раскрытие интересов» | 🟡 | 🤖→👤 | ⬜ | Сейчас пуст |
| **MIG-019** | Миграция 11 RSS на Hugo | Парсинг → Hugo → GitHub Pages → DNS → 301 | 🟡 | 🤖→👤 | ⬜ | После Фазы 1 |
| **MIG-020** | Пантеон: Этап 1 → Этап 2 | Статический дамп (Hugo) → Astro + YOS/DuckDB | 🟡 | 🤖→👤 | ⬜ | 350 → 16 505 страниц поэтапно |
| **MIG-022** | САН: витрина → Next.js | Статическая заглушка (без ПДн) → `can-secure-dev`/Vercel | 🟢 | 🤖→👤 | ❌ | Отменено: план САН изменён на Hugo (см. STRATEGY.md) |
| **UIX-001** | Интерактив: стратегия деградации | Этап 1: комментарии в архиве, формы через Formspree; Этап 2+: анонимизация ПДн | 🟡 | 🤖→👤 | ⬜ | 152-ФЗ |

---

## 🗂️ Реестр артефактов (источник правды)

> Манифесты ссылаются на этот раздел. Один артефакт = одна строка.

### Блок А: Существует в репо `blago-nko/manifests` (33 файла)

Все файлы физически существуют, но **не тестировались** после «Эпохального сброса».

| Путь | Манифест | Статус | Задача | Имя определено |
| :--- | :--- | :---: | :--- | :---: |
| `scripts/apply_arch_patches.py` | AGENTS/САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-001 | ✅ Да |
| `scripts/blogger_page_parser.py` | МИГРАЦИЯ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-001 | ✅ Да |
| `scripts/blogger_postid_rescue.py` | МИГРАЦИЯ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-001 | ✅ Да |
| `scripts/image_storage_adapter.py` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-001 | ✅ Да |
| `scripts/pdn_scanner.py` | САН | ✅ Проверено (VERIFY-001/002/003) | VERIFY-001 | ✅ Да |
| `scripts/sanitize_images.py` | САМ/СУМКа | ✅ Проверено (VERIFY-001/002/003) | VERIFY-001 | ✅ Да |
| `scripts/sync_manifests.py` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-001 | ✅ Да |
| `scripts/sync_readme_licenses.py` | ЛИЦ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-001 | ✅ Да |
| `scripts/sync_readme_sections.py` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-001 | ✅ Да |
| `scripts/update_status.py` | САМ/СУМКа | ✅ Проверено (VERIFY-001/002/003) | VERIFY-001 | ✅ Да |
| `scripts/branch-protection.json` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-003 | ✅ Да |
| `scripts/ruleset.json` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-003 | ✅ Да |
| `scripts/ruleset-repo.json` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-003 | ✅ Да |
| `.github/workflows/apply-architecture-patches.yml` | AGENTS | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/workflows/architecture-check.yml` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/workflows/auto-update-status.yml` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/workflows/license-check.yml` | ЛИЦ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/workflows/manifest-consistency-check.yml` | INFRA | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/workflows/manifest-lint.yml` | INFRA | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/workflows/markdown-lint.yml` | INFRA | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/workflows/pr-prefix-check.yml` | AGENTS | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/workflows/readme-license-check.yml` | ЛИЦ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/workflows/sync-manifests.yml` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/workflows/sync-readme-sections.yml` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/workflows/update-manifest-dates.yml` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/workflows/update-status.yml` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-002 | ✅ Да |
| `.github/PULL_REQUEST_TEMPLATE.md` | AGENTS | ✅ Проверено (VERIFY-001/002/003) | VERIFY-003 | ✅ Да |
| `docs/manifests.yaml` | САМ/README | ✅ Проверено (VERIFY-001/002/003) | VERIFY-003 | ✅ Да |
| `docs/STATUS.md` | САМ/МИГРАЦИЯ/СУМКа | ✅ Проверено (VERIFY-001/002/003) | VERIFY-003 | ✅ Да |
| `.cursorrules` | САМ | ✅ Проверено (VERIFY-001/002/003) | VERIFY-003 | ✅ Да |
| `.markdownlint-cli2.jsonc` | INFRA | ✅ Проверено (VERIFY-001/002/003) | VERIFY-003 | ✅ Да |
| `.markdownlint.yaml` | INFRA | ✅ Проверено (VERIFY-001/002/003) | VERIFY-003 | ✅ Да |
| `.markdownlintignore` | INFRA | ✅ Проверено (VERIFY-001/002/003) | VERIFY-003 | ✅ Да |

### Блок Б: Отсутствует — имя определено (требуют создания)

Файлы, которых нет ни в одном репозитории (репозитории `shared-assets` и доменные удалены при сбросе 11.09.2026). Имя и путь известны из манифестов.

| Путь | Манифест | Статус | Задача | Имя определено |
| :--- | :--- | :---: | :--- | :---: |
| `generate_sitemaps.py` | СУМКа/ГРЕК-ПАНТЕОН | ❌ Отсутствует | MIG-013 | ✅ Да |
| `ping_search_engines.py` | СУМКа | ❌ Отсутствует | MIG-013 | ✅ Да |
| `image_sanitizer.py` | САМ | ❌ Отсутствует | MIG-013 | ✅ Да |
| `generate_redirect_map.py` | МИГРАЦИЯ | ❌ Отсутствует | MIG-020 | ✅ Да |
| `build_static_rss.py` | МИГРАЦИЯ | ❌ Отсутствует | MIG-020 | ✅ Да |
| `extract_original_author.py` | МИГРАЦИЯ | ❌ Отсутствует | MIG-020 | ✅ Да |
| `slug_optimizer.py` | МИГРАЦИЯ | ❌ Отсутствует | MIG-020 | ✅ Да |
| `video_link_processor.py` | МИГРАЦИЯ/САН | ❌ Отсутствует | *новая задача* | ✅ Да |
| `grekpanteon_pipeline.py` | ГРЕК-ПАНТЕОН | ❌ Отсутствует | MIG-021 | ✅ Да |
| `build_static_dump.py` | ГРЕК-ПАНТЕОН | ❌ Отсутствует | MIG-021 | ✅ Да |
| `build_astro_data.py` | ГРЕК-ПАНТЕОН | ❌ Отсутствует | MIG-021 | ✅ Да |
| `image_source_extractor.py` | ГРЕК-ПАНТЕОН | ❌ Отсутствует | MIG-021 | ✅ Да |
| `generate_causal_links.py` | ГРЕК-ПАНТЕОН | ❌ Отсутствует | MIG-021 | ✅ Да |
| `build_geojson_by_generation.py` | ГРЕК-ПАНТЕОН | ❌ Отсутствует | MIG-021 | ✅ Да |
| `monitor_daily_publication.py` | ГРЕК-ПАНТЕОН | ❌ Отсутствует | MIG-021 | ✅ Да |
| `rollback_publication.py` | ГРЕК-ПАНТЕОН | ❌ Отсутствует | MIG-021 | ✅ Да |
| `migrate_blogger_to_r2.py` | САМ/СУМКа | ❌ Отсутствует | MIG-010 | ✅ Да |
| `social_distribution_worker.js` | СУМКа | ❌ Отсутствует | *новая задача* | ✅ Да |
| `shared-assets/identity_graph.json` | САМ, СУМКа | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/video_alternatives_db.json` | САМ, СУМКа | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/blogger_image_metadata.json` | САМ, СУМКа | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/config/verification.json` | САМ, СУМКа | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/config/social_links.json` | САМ, СУМКа | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/config/image_storage_routing.json` | САМ, СУМКа | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/config/social_communities_seed.json` | СУМКа | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/components/PrivacyPolicyLink.js` | САМ | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/components/MultiVolumeNavigation.js` | МИГРАЦИЯ | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/components/StickyBottomBar.js` | МИГРАЦИЯ | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/adapters/SocialDistributionAdapter.js` | СУМКа | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/widgets/feedback-simple.js` | МИГРАЦИЯ | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/schemas/book-chapter.jsonld` | МИГРАЦИЯ | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `shared-assets/templates/layout.html` | МИГРАЦИЯ | ❌ Отсутствует | INFRA-010 | ✅ Да |
| `{каждый_сайт}/migration_seo_map.json` | МИГРАЦИЯ, САН, ГРЕК-ПАНТЕОН | ❌ Отсутствует | MIG-020, MIG-021 | ✅ Да |
| `{каждый_сайт}/media_passport.json.gz` | САМ, МИГРАЦИЯ, ГРЕК-ПАНТЕОН | ❌ Отсутствует | MIG-013 | ✅ Да |
| `{каждый_сайт}/authors_override.json` | МИГРАЦИЯ | ❌ Отсутствует | MIG-020 | ✅ Да |
| `{каждый_сайт}/ai-hints.txt` | СУМКа, ГРЕК-ПАНТЕОН | ❌ Отсутствует | MIG-020, MIG-021 | ✅ Да |
| `docs/DEVELOPMENT_TOOLS.md` | САМ/СУМКа | ❌ Отсутствует | INFRA-004 | ✅ Да |
| `docs/IMAGE_SANITIZATION_GUIDE.md` | САМ | ❌ Отсутствует | INFRA-004 | ✅ Да |
| `docs/BLOGGER_IMAGE_STORAGE_GUIDE.md` | САМ/СУМКа | ❌ Отсутствует | INFRA-004 | ✅ Да |
| `docs/SOCIAL_DISTRIBUTION_GUIDE.md` | СУМКа | ❌ Отсутствует | INFRA-004 | ✅ Да |
| `docs/SOCIAL_COMMUNITY_MANAGEMENT.md` | СУМКа | ❌ Отсутствует | INFRA-004 | ✅ Да |
| `docs/SEARCH_CONSOLE_SETUP.md` | СУМКа | ❌ Отсутствует | INFRA-004 | ✅ Да |
| `docs/SITEMAP_GENERATION_GUIDE.md` | СУМКа | ❌ Отсутствует | INFRA-004 | ✅ Да |
| `docs/SLUG_OPTIMIZATION_QUEUE.json` | МИГРАЦИЯ | ❌ Отсутствует | INFRA-004 | ✅ Да |
| `.github/workflows/backup_blogger_metadata.yml` | САМ/СУМКа | ❌ Отсутствует | INFRA-012 | ✅ Да |
| `.github/workflows/backup-content.yml` | САМ | ❌ Отсутствует | INFRA-012 | ✅ Да |
| `.github/workflows/publish-assets.yml` | САМ | ❌ Отсутствует | INFRA-012 | ✅ Да |
| `.github/workflows/ai-rules-sync.yml` | САМ | ❌ Отсутствует | INFRA-012 | ✅ Да |
| `.github/workflows/protocol-check.yml` | AGENTS | ❌ Отсутствует | INFRA-012 | ✅ Да |
| `.github/copilot-instructions.md` | САМ §3.3.5 | ❌ Отсутствует | INFRA-012 | ✅ Да |
| `legal/privacy-policy.html` | САМ | ❌ Отсутствует | INFRA-103 | ✅ Да |
| `hugo/layouts/shortcodes/img.html` | МИГРАЦИЯ/СУМКа | ❌ Отсутствует | INFRA-104 | ✅ Да |
| `scripts/validate_redirect_map.py` | МИГРАЦИЯ | ❌ Отсутствует | INFRA-106 | ✅ Да |

### Блок В: Отсутствует — концепты (имя не определено)

Требования к функциональности, для которых **ещё не определено** имя файла, путь и интерфейс**. Перед созданием требуется отдельная задача проектирования.

| Назначение | Манифест | Принцип/Раздел | Статус | Задача | Имя определено |
| :--- | :--- | :--- | :---: | :--- | :---: |
| Скрипт троттлинга публикаций (200/сутки) | САМ | Принцип 2.6 | ❌ Отсутствует | *новая задача* | ❌ Нет |
| ИИ-агент Технический писатель | САМ | Принцип 2.11 | ❌ Отсутствует | *новая задача* | ❌ Нет |
| Скрипт зомби-аудита (Data Decay) | САМ | Принцип 3.6 | ❌ Отсутствует | *новая задача* | ❌ Нет |
| Таблицы БД: журнал транзакций, журнал доступа к ПДн, журнал соц-постов, неудачные строки извлечения | САМ | Принцип 3.14 | ❌ Отсутствует | *новая задача* | ❌ Нет |
| Скрипт аварийной миграции с Блоггера в Р2 | САМ | Принцип 3.21 | ❌ Отсутствует | MIG-010 | ❌ Нет |
| ИИ-агент инспектор контента (детекция фрода) | СУМКа | Раздел 11.3 | ❌ Отсутствует | *новая задача* | ❌ Нет |
| Скрипт генерации тематического паспорта | СУМКа | Раздел 3 | ❌ Отсутствует | MIG-013 | ❌ Нет |
| Конвейер санитарной обработки изображений (как компонент) | СУМКа | Раздел 5.6 | ❌ Отсутствует | MIG-013 | ❌ Нет |
| Адаптер MinIO ETL | САН | Раздел 1.3 | ❌ Отсутствует | INFRA-010 | ❌ Нет |
| Системный промпт для ИИ-конвейера Пантеона | ГРЕК-ПАНТЕОН | Раздел 4.1 | ❌ Отсутствует | MIG-021 | ❌ Нет |
| Hugo-шаблон image-with-source.html | ГРЕК-ПАНТЕОН | Раздел 7.3 | ❌ Отсутствует | MIG-021 | ❌ Нет |
| Mobile-First макет layout.html | МИГРАЦИЯ | Раздел 5.1.1.7 | ❌ Отсутствует | MIG-020 | ❌ Нет |
| Скрипт генерации статических страниц Пантеона | МИГРАЦИЯ | Раздел 5.1.3 | ❌ Отсутствует | MIG-021 | ❌ Нет |
| Скрипт миграции между слоями хранения | САМ | Принцип 4.9 | ❌ Отсутствует | MIG-010 | ❌ Нет |

---

## 📚 Источники требований и юридические документы (не артефакты)

Эти файлы **не являются артефактами** (это нормативные документы и источники требований). Их состояние отслеживается через workflows `update-manifest-dates.yml` и `sync-readme-sections.yml`.

| Файл | Назначение |
| :--- | :--- |
| `САМ.md` | Системный Архитектурный Манифест (высший приоритет) |
| `САН.md` | Манифест платформы САН |
| `СУМКа.md` | Манифест системы управления медиа-контентом |
| `ГРЕК-ПАНТЕОН.md` | Манифест базы знаний по античной мифологии |
| `МИГРАЦИЯ.md` | План миграции 14 доменов |
| `ЛИЦ.md` | Лицензионный пакет |
| `AGENTS.md` | Инструкции для ИИ-агентов |
| `README.md` | Описание репозитория и сводная таблица манифестов |
| `STATUS.md` (корень) | Операционное состояние экосистемы (автогенерируется) |
| `LICENSE` | Лицензия для кода (AGPLv3) |
| `LICENSE-CONTENT` | Лицензия для контента (CC BY-NC 4.0) |

---

## Процесс обновления реестра

1. Закрыт протокол (смержен PR) → ИИ-агент обновляет `TASKS.md` (статусы, Реестр артефактов).
2. Человек-подтверждение (Основатель) проверяет и фиксирует.
3. Автосинхронизация в `STATUS.md`, `docs/manifests.yaml`, `README.md`.

## Дизайн-система и финализация пилота (INFRA-074–100)

- [x] INFRA-074: tap-target 44px скоуп (навигация/кнопки); инлайн-ссылки в потоке текста (тело статей, описания и заголовки карточек) -> display:inline; min-height:0
- [x] INFRA-075–076: дизайн-токены + фикс загрузки (link в head вместо @import)
- [x] INFRA-077: карточки постов, горизонтальная шапка, cookie-баннер
- [x] INFRA-078–079: контейнеры, полноширинные полосы, колонка чтения 75ch
- [x] INFRA-080: бренд-шапка (h1+теглайн без дубля), теги-ссылки, индиго-полосы
- [x] INFRA-081: модульная шкала типографики (норматив в СУМКа)
- [x] INFRA-084: бар индиго, cookie над баром, шрифт PT Sans/Serif
- [x] INFRA-085: чёрный cookie-баннер, safe-area
- [x] INFRA-086: drawer над cookie, горизонтальное меню
- [x] INFRA-087: промежуточный пресет Вариант А
- [x] INFRA-088: итоговая типографика (веса 400/700, тело 18px, h1 28px)
- [x] INFRA-089: медиа-радиус как блоки, бренд 22px
- [x] INFRA-090: логотип в шапке (params.logo + SVG-fallback), фикс .brand row, санитария FETCH_HEAD
- [x] INFRA-092: двухцветие названия + янтарная линия
- [x] INFRA-093: адаптивный бар (portrait снизу / landscape справа) — отменён по решению Основателя
- [x] INFRA-094: фикс линии по тексту (094a), revert 093, пропорции логотипа (094b), увеличение логотипа (094c/d)
- [x] INFRA-095: меню column везде + flex-wrap
- [x] INFRA-097: Pagefind в подкаталоге Pages: glob **/index.html; изоляция контента data-pagefind-body условно по .Kind==page (листинги/главная/таксономии вне индекса); клиентский фразовый режим против шума предлогов; data-pagefind-weight на h1
- [x] INFRA-098: убрана стандартная подсветка ссылок при тапе на мобильных
- [x] INFRA-100: тёмная тема — persistence выбора, логотип WebP 5.5 КБ, контраст подзаголовка и элементов поиска (PageSpeed Accessibility 100/100)

- [x] Оригиналы изображений пилота (перескачка из Blogger, 2026-09-22)
- [ ] INFRA-082: Sticky Bottom Bar (моб.) + полировка (focus-states, CLS)
- [ ] INFRA-083: rollout-план 12 сайтов (порядок, чек-листы, откат)

## 📅 Приоритизация этапов (Обновлено: 2026-10-10)

### 🔥 Фаза 1: Миграция Контента (CURRENT PRIORITY)

Цель: Перенести текст и структуру 13 сайтов с Blogger на Hugo.
Стратегия медиа: **Link Preservation** (сохранение ссылок на googleusercontent).

| ID | Название | Описание | Приоритет | Статус |
| :--- | :--- | :--- | :--- | :--- |
| **MIG-CORE-EXECUTE** | Массовый парсинг Blogger API | Извлечение постов, конвертация в Markdown, сохранение img src как есть. | 🔴 CRITICAL | ⬜ TODO |
| **MIG-HUGO-THEME** | Адаптация темы Hugo | Настройка шаблонов для отображения legacy-контента. | 🟠 HIGH | ⬜ IN PROGRESS |

### ⏸️ Фаза 2: Инфраструктура Хранения (DEFERRED)

Цель: Изоляция данных от зависимостей Google. Активируется ТОЛЬКО после успеха Фазы 1.
Стратегия медиа: **Asset Consolidation** (перенос в Cloudflare R2).

| ID | Название | Причина отложенности | Статус |
| :--- | :--- | :--- | :--- |
| **INFRA-R2-SETUP** | Создание бакета Cloudflare R2 | Не требуется для текущей миграции текста. Блокирует ресурсы. | ⏸️ DEFERRED |
| **DEV-R2-LIBRARY** | Скрипт r2_uploader.py | Инструмент готов, но внедрение преждевременно. | ⏸️ DEFERRED |
| **MIG-SAN-R2** | Перенос картинок САН в R2 | Требует завершенной миграции сайта САН на Hugo. | ⏸️ BLOCKED BY PHASE 1 |
| **MIG-PANTEON-R2** | Перенос картинок Пантеона в R2 | Требует завершенной миграции сайта Пантеон на Hugo. | ⏸️ BLOCKED BY PHASE 1 |

## Задачи по результатам аудита пилотных репозиториев (2026-10-11)

### INFRA-119: Добавить favicon.ico в obrazslov

- **Репозиторий:** blago-nko/obrazslov
- **Приоритет:** Высокий
- **Статус:** ⬜ Не начато
- **Описание:** Создать static/favicon.ico для соответствия требованиям пилота
- **Критерии приёмки:** Файл существует и отображается в браузере
- **Связанные задачи:** MIG-002

### INFRA-120: Добавить manifest.json в obrazslov

- **Репозиторий:** blago-nko/obrazslov
- **Приоритет:** Средний
- **Статус:** ⬜ Не начато
- **Описание:** Создать static/manifest.json для PWA поддержки
- **Критерии приёмки:** Валидный JSON с необходимыми полями (name, short_name, start_url, display, icons)
- **Связанные задачи:** MIG-002

### INFRA-121: Обновить .gitignore в obrazslov

- **Репозиторий:** blago-nko/obrazslov
- **Приоритет:** Низкий
- **Статус:** ⬜ Не начато
- **Описание:** Добавить исключение pagefind/ в .gitignore
- **Критерии приёмки:** pagefind/ присутствует в .gitignore
- **Связанные задачи:** MIG-002

### INFRA-122: Обновить .gitignore в manifests

- **Репозиторий:** blago-nko/manifests
- **Приоритет:** Низкий
- **Статус:** ⬜ Не начато
- **Описание:** Добавить исключения public/ и pagefind/ в .gitignore
- **Критерии приёмки:** public/ и pagefind/ присутствуют в .gitignore
- **Связанные задачи:** INFRA-034

### INFRA-123: Обновить .gitignore в shared-assets

- **Репозиторий:** blago-nko/shared-assets
- **Приоритет:** Низкий
- **Статус:** ⬜ Не начато
- **Описание:** Добавить исключения public/ и pagefind/ в .gitignore
- **Критерии приёмки:** public/ и pagefind/ присутствуют в .gitignore
- **Связанные задачи:** INFRA-050
